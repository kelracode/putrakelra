'use strict';
// Hades PlayOs Web: logika PlayOs (cari judul YouTube, batas durasi, throttle + cooldown 429,
// playlist persisten maks 500) tanpa Telegram.
const http = require('http'), https = require('https'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = Number(process.env.SERVER_PORT || process.env.PORT || 3301);
const MAX_DUR = Math.max(30, Number(process.env.MAX_DURATION_SECONDS || 900));
const MIN_INT = Math.max(1500, Number(process.env.SEARCH_MIN_INTERVAL_MS || 5000));
const COOLDOWN = Math.max(60000, Number(process.env.SEARCH_COOLDOWN_MS || 600000));
const KEY = process.env.ACCESS_KEY || '';
const TEMP = path.join(__dirname, 'temp'), PLF = path.join(__dirname, 'data', 'playlists.json');
fs.mkdirSync(TEMP, { recursive: true }); fs.mkdirSync(path.dirname(PLF), { recursive: true });
for (const f of fs.readdirSync(TEMP)) fs.rmSync(path.join(TEMP, f), { force: true });

let ffmpeg = ''; try { ffmpeg = require('ffmpeg-static') || ''; } catch {}
if (ffmpeg) process.env.PATH = path.dirname(ffmpeg) + path.delimiter + (process.env.PATH || '');
const yt = () => { const y = require('youtube-dl-exec'); return process.env.YT_DLP_PATH ? y.create(process.env.YT_DLP_PATH) : y; };

const sleep = ms => new Promise(r => setTimeout(r, ms));
const errMsg = e => String(e?.stderr || e?.message || e || 'Unknown error').trim();
const limited = e => /HTTP Error 429|Too Many Requests|confirm you.?re not a bot|confirm you are not a bot/i.test(errMsg(e));
const parse = r => { if (r && typeof r === 'object' && typeof r.stdout === 'string') r = r.stdout; if (Buffer.isBuffer(r)) r = r.toString(); return typeof r === 'string' ? JSON.parse(r) : r; };

// ---- throttle: satu request pada satu waktu, jeda minimum, cooldown saat 429 ----
let last = 0, cool = 0, lock = Promise.resolve();
async function throttled(fn) {
  const prev = lock; let rel; lock = new Promise(r => (rel = r)); await prev;
  try {
    const n = Date.now();
    if (n < cool) throw Object.assign(new Error(`YouTube sedang membatasi permintaan. Coba lagi sekitar ${Math.ceil((cool - n) / 1000)} detik.`), { soft: true });
    const w = Math.max(0, last + MIN_INT - n); if (w) await sleep(w); last = Date.now();
    return await fn();
  } catch (e) { if (limited(e)) cool = Date.now() + COOLDOWN; throw e; } finally { rel(); }
}

// ---- playlist persisten ----
let playlist = []; try { const p = JSON.parse(fs.readFileSync(PLF, 'utf8')); if (Array.isArray(p)) playlist = p; } catch {}
const savePl = () => { const t = `${PLF}.${process.pid}.tmp`; fs.writeFileSync(t, JSON.stringify(playlist, null, 1), { mode: 0o600 }); fs.renameSync(t, PLF); };
function addPl(t, query) {
  playlist = playlist.filter(x => x.vid !== t.vid);
  playlist.unshift({ id: crypto.randomBytes(6).toString('hex'), vid: t.vid, query: String(query || t.title).slice(0, 300), title: t.title, artist: t.artist, thumb: t.thumb, duration: t.duration, addedAt: Date.now() });
  if (playlist.length > 500) playlist.length = 500; savePl();
}

// ---- cari & siapkan audio ----
const meta = new Map(); const mk = (id, o) => ({ vid: id, title: String(o.title || id).slice(0, 180), artist: String(o.artist || o.uploader || o.channel || 'YouTube').slice(0, 180), duration: Number(o.duration) || 0, thumb: `https://i.ytimg.com/vi/${id}/mqdefault.jpg` });
async function search(q) {
  q = String(q || '').trim().slice(0, 200);
  if (!q) throw new Error('Masukkan judul lagu untuk pencarian.');
  if (/^(https?:\/\/|www\.)/i.test(q) || /(youtube\.com|youtu\.be)/i.test(q)) throw new Error('Gunakan judul lagu, bukan URL YouTube.');
  const j = parse(await throttled(() => yt()(`ytsearch8:${q}`, { dumpSingleJson: true, flatPlaylist: true, skipDownload: true, noWarnings: true, socketTimeout: 30000, retries: 0 })));
  const out = (j.entries || []).filter(e => e && /^[\w-]{11}$/.test(e.id || '')).map(e => { const t = mk(e.id, e); meta.set(t.vid, t); return t; });
  if (!out.length) throw new Error('Lagu tidak ditemukan.');
  return out;
}
const jobs = new Map(); let dl = Promise.resolve();
async function getMeta(id) {
  if (meta.has(id)) return meta.get(id);
  const pl = playlist.find(x => x.vid === id); if (pl) return pl;
  const j = parse(await throttled(() => yt()(`https://www.youtube.com/watch?v=${id}`, { dumpSingleJson: true, skipDownload: true, noPlaylist: true, noWarnings: true, socketTimeout: 30000, retries: 0 })));
  const t = mk(id, j); meta.set(id, t); return t;
}
function prepare(id) {
  if (!/^[\w-]{11}$/.test(id)) return Promise.reject(new Error('ID lagu tidak valid.'));
  if (jobs.has(id)) return jobs.get(id);
  const job = (async () => {
    const t = await getMeta(id);
    if (!(t.duration > 0)) throw new Error('Durasi audio tidak dapat dibaca dari YouTube.');
    if (t.duration > MAX_DUR) throw new Error(`Durasi audio ${Math.ceil(t.duration)} detik melebihi batas ${MAX_DUR} detik.`);
    const out = path.join(TEMP, `${id}.mp3`);
    if (!fs.existsSync(out)) {
      const run = dl.then(() => yt()(`https://www.youtube.com/watch?v=${id}`, { noPlaylist: true, extractAudio: true, audioFormat: 'mp3', audioQuality: 0, maxFilesize: '100M', ffmpegLocation: ffmpeg || undefined, output: out, noWarnings: true, socketTimeout: 60000, retries: 0, fragmentRetries: 1 }));
      dl = run.catch(() => {}); await run;
    }
    if (!fs.existsSync(out) || fs.statSync(out).size < 4096) { fs.rmSync(out, { force: true }); throw new Error('File audio tidak valid.'); }
    prune(); return t;
  })().catch(e => { if (limited(e)) { cool = Math.max(cool, Date.now() + COOLDOWN); throw new Error('YouTube sedang membatasi akses otomatis (429 / pemeriksaan bot). Coba lagi nanti.'); } throw e.soft ? e : new Error(errMsg(e).slice(-400)); }).finally(() => jobs.delete(id));
  jobs.set(id, job); return job;
}
function prune() { // simpan 60 file terbaru
  const f = fs.readdirSync(TEMP).map(n => ({ n, t: fs.statSync(path.join(TEMP, n)).mtimeMs })).sort((a, b) => b.t - a.t);
  for (const x of f.slice(60)) fs.rmSync(path.join(TEMP, x.n), { force: true });
}

// ---- HTTP ----
const json = (res, code, o) => { const b = JSON.stringify(o); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(b); };
const body = req => new Promise(r => { let s = ''; req.on('data', c => { if ((s += c).length > 1e5) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(s || '{}')); } catch { r({}); } }); });
function audio(req, res, id) {
  const f = path.join(TEMP, `${id}.mp3`); let st; try { st = fs.statSync(f); } catch { res.writeHead(404); return res.end(); }
  let s = 0, e = st.size - 1; const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  if (m) { if (m[1]) s = +m[1]; if (m[2]) e = Math.min(+m[2], e); if (!m[1] && m[2]) { s = st.size - +m[2]; e = st.size - 1; } }
  if (s > e || s < 0) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
  res.writeHead(m ? 206 : 200, { 'Content-Type': 'audio/mpeg', 'Accept-Ranges': 'bytes', 'Content-Length': e - s + 1, ...(m && { 'Content-Range': `bytes ${s}-${e}/${st.size}` }) });
  fs.createReadStream(f, { start: s, end: e }).pipe(res);
}
async function handler(req, res) {
  const u = new URL(req.url, 'http://x'), p = u.pathname;
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (p === '/' || p === '/index.html') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return fs.createReadStream(path.join(__dirname, 'public', 'index.html')).pipe(res); }
  if (!p.startsWith('/api/')) { res.writeHead(404); return res.end(); }
  if (KEY && (req.headers['x-key'] || u.searchParams.get('key')) !== KEY) return json(res, 401, { error: 'Kunci akses salah.' });
  try {
    let m;
    if ((m = /^\/api\/audio\/([\w-]{11})$/.exec(p))) return audio(req, res, m[1]);
    if (p === '/api/config') return json(res, 200, { maxDuration: MAX_DUR });
    if (p === '/api/search') return json(res, 200, { results: await search(u.searchParams.get('q')) });
    if (p === '/api/prepare' && req.method === 'POST') { const b = await body(req); const t = await prepare(String(b.id || '')); addPl(t, b.query); return json(res, 200, { track: t }); }
    if (p === '/api/playlist') return json(res, 200, { playlist });
    if ((m = /^\/api\/playlist\/(\w+)$/.exec(p)) && req.method === 'DELETE') { playlist = playlist.filter(x => x.id !== m[1]); savePl(); return json(res, 200, { ok: true }); }
    return json(res, 404, { error: 'Tidak ditemukan.' });
  } catch (e) { console.error('[ERR]', errMsg(e)); return json(res, 400, { error: errMsg(e).slice(0, 300) }); }
}
let server;
try {
  const c = process.env.SSL_CERT, k = process.env.SSL_KEY;
  server = c && k ? https.createServer({ cert: fs.readFileSync(c), key: fs.readFileSync(k) }, handler) : http.createServer(handler);
  console.log(c && k ? 'HTTPS aktif' : 'HTTP aktif (set SSL_CERT & SSL_KEY untuk HTTPS)');
} catch (e) { console.error('SSL gagal dimuat:', e.message); process.exit(1); }
server.listen(PORT, '0.0.0.0', () => console.log(`Hades PlayOs Web berjalan di port ${PORT}`));
process.on('unhandledRejection', e => console.error('[UNHANDLED]', errMsg(e)));
