# Hades PlayOs Web

Jalankan di panel (Pterodactyl): Node 20+, port utama 3301, startup `npm start`.

Env opsional: ACCESS_KEY (kunci akses), MAX_DURATION_SECONDS (900), SSL_CERT + SSL_KEY (path cert/key agar HTTPS aktif), YT_DLP_PATH, SEARCH_MIN_INTERVAL_MS, SEARCH_COOLDOWN_MS.
