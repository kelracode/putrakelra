# Hades PlayOs — Web2APK

This package keeps the original Hades PlayOs Node.js server and web client intact, and adds an Android WebView wrapper plus a GitHub Actions workflow that builds an installable debug APK.

## Important: the backend still needs to run

The Android app opens `http://alanwinter.alannxd.my.id:3301`. That host must serve the original Hades PlayOs `server.js` application and its `/api/*` endpoints. The APK wrapper does not replace the Node.js backend or bundle YouTube extraction/FFmpeg into Android.

Deploy the original project root (`package.json`, `server.js`, `public/`) on a Node.js 20+ host, expose port 3301, and start it with `npm start`. Keep the existing server environment variables as documented in `README.md`.

## Build APK

1. Push this extracted project to a GitHub repository.
2. Open **Actions** → **Hades PlayOs Web2APK**.
3. Select **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the run's **Artifacts** section and download `Hades-PlayOs-APK`.
6. Extract the artifact and install `app-debug.apk` on Android.

## Change the website URL

Edit `START_URL` in:

`android/app/src/main/java/com/hades/playos/MainActivity.java`

Then push the change and run the workflow again.

## Preserved source

The original `server.js`, `public/index.html`, and `package.json` are included unchanged. The Android wrapper only loads the deployed web app, so all existing website/API logic remains on the Node.js server.
